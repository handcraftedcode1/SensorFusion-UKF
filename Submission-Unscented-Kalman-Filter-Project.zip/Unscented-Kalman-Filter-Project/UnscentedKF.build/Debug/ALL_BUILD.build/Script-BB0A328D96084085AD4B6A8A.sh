#!/bin/sh
make -C /Users/kmartin/Repos/Nanodegree/Term2/Projects/Unscented-Kalman-Filter-Project -f /Users/kmartin/Repos/Nanodegree/Term2/Projects/Unscented-Kalman-Filter-Project/CMakeScripts/ALL_BUILD_cmakeRulesBuildPhase.make$CONFIGURATION all
