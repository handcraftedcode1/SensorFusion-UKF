#!/bin/sh
make -C /Users/kmartin/Repos/Nanodegree/Term2/Projects/Unscented-Kalman-Filter-Project -f /Users/kmartin/Repos/Nanodegree/Term2/Projects/Unscented-Kalman-Filter-Project/CMakeScripts/ZERO_CHECK_cmakeRulesBuildPhase.make$CONFIGURATION all
